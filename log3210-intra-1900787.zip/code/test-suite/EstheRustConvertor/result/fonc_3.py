def greet(name, bue):
	a = -45.0
	return (True and False) or False


