def operateur_coeur():
	print("Compilateurs est le meilleur cours au monde")


