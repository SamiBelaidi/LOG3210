a = True or False
b = False
if a == b:
	megantheestalion = "Body ody ody ody ody ody ody........"
	allo = -0.98533545
	if True and False or False != False:
		patricksebastien = "ET ON FAIT TOURNER LES SERVIETTES *flute flute flute*"
		if False:
			pass
