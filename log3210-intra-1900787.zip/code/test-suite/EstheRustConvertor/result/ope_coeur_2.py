if (90 < 2) > 4:
	print("Compilateurs est le meilleur cours au monde")
