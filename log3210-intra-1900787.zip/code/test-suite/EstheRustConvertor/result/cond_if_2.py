if True:
	fiftycent = "hey shawty, it's your birthday. We gonna party like it's your birthday."
