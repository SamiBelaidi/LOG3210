import decimal
import random
