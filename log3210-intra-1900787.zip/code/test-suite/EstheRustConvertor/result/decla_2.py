import decimal
import random
variable1 = "dfsfsdfsdfs"
variable2 = True
variable3 = False
variable4 = 9
variable5 = 9
variable6 = 9
variable7 = 9.0
variable8 = 0.987
variable9 = -123.456E+78
