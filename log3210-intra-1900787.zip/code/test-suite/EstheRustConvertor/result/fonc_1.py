def exemple2(name):
	a = "test1"


