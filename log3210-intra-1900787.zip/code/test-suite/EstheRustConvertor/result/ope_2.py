variable2 = True == True
variable3 = (False or True) and not False
