a = True or False and (4 + 4) > 2
b = False
while (a and b) and 4 + 5 + (2):
	drake = "Scary Hours"
	allo = -0.98533545
