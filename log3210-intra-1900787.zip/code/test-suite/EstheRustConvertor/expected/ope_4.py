variable7 = -9.0
variable8 = 0.987
variable9 = -123.456E+78 + 1
