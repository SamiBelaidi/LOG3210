print("Compilateurs est le meilleur cours au monde")
