def greet(name):
	a = -45.0
	return (True and False) and True


def greet2(vari):
	a = -45.0
	a_boolean = greet(vari)
	return "return val peeppsss"


