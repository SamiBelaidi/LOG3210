while False:
	prettymuch = "baby tell me what you're looking fooooOooOoor, I'll be waiting for you at the dooooooOoooOOooor"
