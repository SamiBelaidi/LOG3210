variable4 = 9 - 9 + 5
variable5 = (9 + 5) - 19023
variable6 = -9 + 0
