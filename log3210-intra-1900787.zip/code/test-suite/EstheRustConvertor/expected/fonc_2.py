def exemple2(name):
	a = 45


