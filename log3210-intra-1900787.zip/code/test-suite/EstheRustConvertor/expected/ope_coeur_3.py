while True:
	print("Compilateurs est le meilleur cours au monde")
	loveCompi = "compi is love, compi is life"
