import os
variable1 = "dfsfsdfsdfs"
variable2 = True
variable3 = False
variable4 = 9
variable5 = 9
variable6 = 9.0
variable6 = 0.987
def greet(n, m):
	if n:
		pass
	return "retun val"


def greet2():
	pass


def greet3():
	return 1


def greet4():
	return True


def greet5(n, m):
	if n:
		pass
	return "retun val"


n = 1
if greet(n, 15):
	print("fizzbuzz")
if True:
	print("fizz")
if 1 == greet3():
	print("buzz")
	if n:
		pass
else:
	print("bye")
while True:
	pass
while greet4():
	greet5("allo", "bye")
