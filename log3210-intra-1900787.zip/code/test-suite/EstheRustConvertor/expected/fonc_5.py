def bye():
	pass


