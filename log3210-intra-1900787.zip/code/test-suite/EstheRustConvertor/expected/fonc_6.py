def bye():
	pass


bye()
def greet(name):
	a = -45.0
	return (True and False) and True


val = greet(89)
