import decimal
import random
