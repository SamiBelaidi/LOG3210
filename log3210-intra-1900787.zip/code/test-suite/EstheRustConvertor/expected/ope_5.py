import decimal
import random
variable1 = "a b c d e f g h i j k lmnope q r s t u v w x y z. Je connais mon alphabet, du debut jusqu'a la fin!"
variable2 = True != True
variable3 = (not False and not True) and False
variable4 = 9 - 9 - (9 + 9) - 9 + 9
variable5 = ((9 + 5) - 19023)
variable6 = -9 + 0
variable7 = -9.0
variable8 = 0.987
variable9 = (-1283.4509E+78 - 847) - 5
